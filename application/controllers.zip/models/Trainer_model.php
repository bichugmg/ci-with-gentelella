<?php

class Trainer_model extends CI_Model
{   
    function __construct(){
            parent::__construct();
            //load our second db and put in $db2
            $this->db2 = $this->load->database('automation', TRUE);
        }
        
	public function login($email_id,$mob_no)
      {
        $this->db2->where("email_id", $email_id);
        $this->db2->where("mob_no", $mob_no);
        $query = $this->db2->get("trainer");
        $num = $query->num_rows();
        $data["data"]=$query->row();
        $data["count"]=$num;
        return $data;
      }
      
      public function insert_profile($data)
      {
        $this->db2->insert("trainer", $data);
        $last_id=$this->db2->insert_id();
        return $last_id;
      }
      
      public function fetch_course_types(){

        $this->db2->order_by("course_type_id", "asc");
		$query = $this->db2->get('course_type');
		return $query->result_array();
	}
	
	public function get_course_data($id)
      {
        $this->db2->order_by("course_name", "asc");
        $this->db2->where("course.course_type_id", $id);
        return $this->db2->get("course");
      }
      
    public function get_stream_data($id)
      {
        $this->db2->order_by("course_stream_name", "asc");
        $this->db2->where("course_stream.course_id", $id);
        return $this->db2->get("course_stream");
      }
	
      public function fetch_districts(){

        $this->db2->order_by("district_id", "desc");
		$query = $this->db2->get('district');
		return $query->result_array();
	}
	
	public function fetch_regions(){

        $this->db2->order_by("region_name", "asc");
		$query = $this->db2->get('region');
		return $query->result_array();
	}
	
	public function get_region_data($id)
      {
        $this->db2->order_by("region_name", "asc");
        $this->db2->where("region.district_id", $id);
        return $this->db2->get("region");
      }
      
    public function get_branch_data($id,$id_2)
      {
        $this->db2->order_by("group", "asc");
        $this->db2->where("studentgroup.region_id", $id);
        $this->db2->or_where("studentgroup.region_id", $id_2);
        return $this->db2->get("studentgroup");
      }
	
	public function fetch_branches(){

        $this->db2->order_by("group", "asc");
		$query = $this->db2->get('studentgroup');
		return $query->result_array();
	}

	public function fetch_subjects(){

        $this->db2->order_by("popular", "asc");
        $this->db2->order_by("subject_name", "asc");
		$query = $this->db2->get('subjects');
		return $query->result_array();
	}
      
    public function update_profile($data,$trainer_id)
      {
        $this->db2->where("trainer_id", $trainer_id);
        $this->db2->update("trainer", $data);
      }
      
    public function insert_trainer_branch($data)
      {
        $this->db2->insert("trainer_branch", $data);
      }
      
    public function insert_trainer_subject($data)
      {
        $this->db2->insert("trainer_subject", $data);
      }
      
    public function fetch_profile($trainer_id)
      {
        $this->db2->where("trainer_id", $trainer_id);
        $query = $this->db2->get("trainer");
        $num = $query->num_rows();
        $data["data"]=$query->row();
        $data["count"]=$num;
        return $data;
      }
      
      public function fetch_prefered_branches($trainer_id)
      {
        $this->db2->where("trainer_id", $trainer_id);
        $query = $this->db2->get("trainer_branch");
        return $query->result_array();
      }
      
      
      public function fetch_prefered_subjects($trainer_id)
      {
        $this->db2->where("trainer_id", $trainer_id);
        $query = $this->db2->get("trainer_subject");
        return $query->result_array();
      }
      
      public function delete_prefered_branches($id)
      {
        $tables = array('trainer_branch');
        $this->db2->where("trainer_id", $id);
        $this->db2->delete($tables);
      }
      
      public function delete_prefered_subjects($id)
      {
        $tables = array('trainer_subject');
        $this->db2->where("trainer_id", $id);
        $this->db2->delete($tables);
      }
        
      public function fetch_branch($branch_id)
      { 
        $this->db2->join('region', 'region.region_id = studentgroup.region_id');
        $this->db2->join('district', 'district.district_id = region.district_id');
        $this->db2->join('zone', 'zone.district_id = district.district_id');
        $this->db2->where("studentgroupID", $branch_id);
        $query = $this->db2->get("studentgroup");
        $num = $query->num_rows();
        $data["data"]=$query->row();
        $data["count"]=$num;
        return $data;
      }
      
      public function fetch_region($region_id)
      { 
        $this->db2->join('district', 'district.district_id = region.district_id');
        $this->db2->join('zone', 'zone.zone_id = district.zone_id');
        $this->db2->where("region_id", $region_id);
        $query = $this->db2->get("region");
        $num = $query->num_rows();
        $data["data"]=$query->row();
        $data["count"]=$num;
        return $data;
      }
      
      public function fetch_course($course_stream_id)
      { 
        $this->db2->join('course', 'course.course_id = course_stream.course_id');
        $this->db2->join('course_type', 'course_type.course_type_id = course.course_type_id');
        $this->db2->where("course_stream_id", $course_stream_id);
        $query = $this->db2->get("course_stream");
        $num = $query->num_rows();
        $data["data"]=$query->row();
        $data["count"]=$num;
        return $data;
      }

}
 
?>