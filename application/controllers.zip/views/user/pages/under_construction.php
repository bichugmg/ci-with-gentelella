<html>
    <style>
         body {
    margin : 0;
    color:black;
}

.outer-container {
    position : absolute;
    display: table;
    width: 100%;
    height: 100%;
    background: #f1f3f2;
}

.inner-container {
    display: table-cell;
    vertical-align: middle;
    text-align: center;
}

.centered-content {
    display: inline-block;
    background: #f1f3f2;
}

img {
   max-width : 100%;
}
    </style>
    <head>
        <title>Team INTERVAL™</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <div class="outer-container">
   <div class="inner-container">
     <div class="centered-content">
        <img src="<?php echo base_url().'assets/users/img/under_construction.jpg';?>"> 
        </div>
   </div>
</div>
    </body>
</html>