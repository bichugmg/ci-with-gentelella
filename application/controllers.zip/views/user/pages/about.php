<style type="text/css">
  .h_blog_item .h_blog_text .h_blog_text_inner.right {
    margin-left: 0px;
    border: none;
  }

  .h_blog_item .h_blog_text .h_blog_text_inner{
    padding: 0px;
  }
</style>


<section class="banner_area">
    <div style="height: 52px;" id="bannerid" style="display:none"></div>
      <div class="banner_inner d-flex align-items-center">
        <div class="overlay"></div>
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-6">
              <div class="banner_content text-center">
                <h2>About Us</h2>
                <div class="page_link">
                  <a href="<?php echo base_url();?>">Home</a>
                  <a >About</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>


<section class="about_area section_gap" style="padding-top: 90px; padding-bottom: 0px;">
      <div class="container">
        <div class="row h_blog_item">
          <div class="col-lg-6">
            <div class="h_blog_img">
              <img class="img-fluid" src="<?php echo base_url();?>assets/users/img/about.jpg" alt="" />
            </div>
          </div>
          <div class="col-lg-6">
            <div class="h_blog_text">
              <div class="h_blog_text_inner left right">
                <h4>Who We Are |</h4>
                <p style="text-align : justify;">
                  &emsp;&emsp; As the world we live in is highly competitive that values an individual by his space, certain student and individuals that match are left out of the competition. We, as a team, recognise that there are differences in learning speed among students which have no place in a  group classroom setting. We understand that there are personal differences in interests, grasping power, memory acquisition, comprehension. Accept that this diversity also applies to their imaginative and innovative abilities. Aims to provide personalised individual based training that caters to the unique needs of each student.
                </p>
                <a class="primary-btn" href="#" id="faqq">
                  Learn More <i class="ti-arrow-right ml-1"></i>
                </a>
              </div>
            </div>
          </div>
        </div>


      </div>
    </section>

    <div class="container">
      <div class="section-top-border">
        <h3 class="mb-30 title_color">Frequenty Asked Questions (FAQs)</h3>
        <div class="row">


<?php foreach ($faqs as $faq): ?>
          <div class="col-lg-12 ques mb-1" style="cursor: pointer;">
            <h4 style="color: #3e8fc3;"><?php echo $faq['question']; ?></h4>
            <blockquote class="generic-blockquote" style="display: none; border-left: 2px solid #3e8fc3;">
              <?php echo $faq['answer']; ?>
            </blockquote>
          </div>

<?php endforeach ?>      
        </div>
      </div>
    </div>




    <script type="text/javascript">
       $(document).ready(function(){

          $(".ques").on("click", function() {
          $(this).children('.generic-blockquote').slideToggle("slow");
          $(this).children('.generic-blockquote').focus();
        });

       });
    </script>