<!-- <?php echo $active; ?> -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <script type="text/javascript">
      // var vpw = (screen.width<=768)?'980':'device-width';
      // document.write('<meta name="viewport" content="width='+vpw+'">');
    </script>
    <link rel="icon" href="img/favicon.png" type="image/png" />
    <title>Team INTERVAL™</title>
    <link rel="icon" href="<?php echo base_url();?>assets/users/img/favicon.png" type="image/png" />
    <title>Edustage Education</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/users/css/bootstrap.css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/users/css/flaticon.css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/users/css/themify-icons.css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/users/vendors/owl-carousel/owl.carousel.min.css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/users/vendors/nice-select/css/nice-select.css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/users/css/font-awesome.css" />
    
    <link rel="stylesheet" href="<?php echo base_url();?>assets/users/select2/select2/css/select2.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/users/select2/select2/css/select2-bootstrap.css">
    
    <!-- main css -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/users/css/style.css" />
    <!-- <link rel="stylesheet" href="<?php echo base_url();?>assets/users/css/custom.css" /> -->
    <script type="text/javascript">
      // var stylesheet = document.styleSheets[7];
      // stylesheet.disabled = true;
      // if(screen.width<=768){
      //   stylesheet.disabled = false;
      // }
    </script>

    

    

    <style type="text/css">
      /*.login{*/
      /*  margin-top: .6em;*/
      /*  margin-right: 5px !important;*/
      /*}*/
      .login .btn{
        background: #3e8fc3;
        border: none;

      }
      .login .btn:hover{
        background: #7e4d8a;
        border: none;
        color: #ffff;
      }
      .login .btn:blur{
        border: none;
      }
      .reg{
        margin-top: 20px;
      }
      .reg .btn{
        background: #7e4d8a;
        border: none;

      }
      .reg .btn:hover{
        background: #3e8fc3;
        border: none;
        color: #ffff;
      }
  @media (max-width: 991px) {
    .single-trainer{
    margin-right: 8px !important;
    margin-left: 8px !important;}

    .login{
        margin-top: 0px;
      }
    .login .btn{
        width: 100%
      }
    }
    .modal-content {
  -webkit-border-radius: 0px !important;
  -moz-border-radius: 0px !important;
  border-radius: 0px !important;
  -webkit-border: 0px !important;
  -moz-border: 0px !important;
  border: 0px !important;
    }

    .banner_area{
      min-height: 200px;
    }
    .banner_area .banner_inner{
      min-height: 200px;
    }
    .banner_area .banner_inner .container{
      margin-top: 80px;
    }
    </style>
<script src="<?php echo base_url();?>assets/users/js/jquery-3.2.1.min.js"></script>
  </head>

  <body>
    <!--================ Start Header Menu Area =================-->
    <header class="header_area navbar_fixed">
      <div class="main_menu">
        <div class="search_input" id="search_input_box" style="display:none;">
          <div class="container">
            <form class="d-flex justify-content-between" method="" action="">
              <input
                type="text"
                class="form-control"
                id="search_input"
                placeholder="Search Here"
              />
              <button type="submit" class="btn"></button>
              <span
                class="ti-close"
                id="close_search"
                title="Close Search"
              ></span>
            </form>
          </div>
        </div>

        <div class="search_input" id="search_input_box2" style="display:none;">
          <div class="container">
           
           <a href="https://play.google.com/store/apps/details?id=com.activision.callofduty.shooter&hl=en_IN" class="genric-btn info-border circle">Get App</a>
           <a href="" data-toggle="modal" data-target="#demoModal" class="genric-btn info-border circle">Book Demo Class</a>

              <span
                class="ti-close float-right"
                id="close_search2"
                title="Close Search"
              ></span>
          </div>
        </div>

        <nav class="navbar navbar-expand-lg navbar-light">
          <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <a class="navbar-brand logo_h" href="<?php echo base_url();?>"
              ><img  height="38px" width="163px" src="<?php echo base_url();?>assets/users/img/logo.png" alt=""
            /></a>
            <button
              class="navbar-toggler"
              type="button"
              data-toggle="collapse"
              data-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span class="icon-bar"></span> <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div
              class="collapse navbar-collapse offset"
              id="navbarSupportedContent"
            >
              <ul class="nav navbar-nav menu_nav ml-auto">
                <li class="nav-item <?php if($active == 'home'){echo 'active';}?>">
                  <a class="nav-link" href="<?php echo base_url();?>">Home</a>
                </li>
                <li class="nav-item <?php if($active == 'course'){echo 'active';}?>">
                      <a class="nav-link" href="<?php echo base_url();?>course">Courses</a>
                    </li>
                <li class="nav-item <?php if($active == 'downloads'){echo 'active';}?>">
                      <a class="nav-link" href="<?php echo base_url();?>home/downloads">Downloads</a>
                    </li>
                
                  
                    <li class="nav-item <?php if($active == 'blog'){echo 'active';}?>">
                      <a class="nav-link" href="<?php echo base_url();?>blog">Blog</a>
                    </li>

                    <li class="nav-item <?php if($active == 'about'){echo 'active';}?>">
                      <a class="nav-link" href="<?php echo base_url();?>home/about">About</a>
                    </li>

                    <li class="nav-item <?php if($active == 'contact'){echo 'active';}?>">
                      <a class="nav-link" href="<?php echo base_url();?>home/contact">Contact</a>
                    </li>


<!-- login -->
<!-- btn btn-primary genric-btn info circle -->

                <li class="nav-item login">
                  <a class="nav-link" data-toggle="modal" data-target="#exampleModalCenter" href="" id="logclick">Login</a>
                </li>

                <!-- <li class="nav-item reg">
                  <a class="btn btn-primary genric-btn info circle" href="contact.html" data-toggle="modal" data-target="#exampleModalCenter"><i class="ti-write"> </i>Register</a>
                </li> -->

                <!-- <li class="nav-item submenu dropdown">
                  <a
                    href="#"
                    class="nav-link dropdown-toggle"
                    data-toggle="dropdown"
                    role="button"
                    aria-haspopup="true"
                    aria-expanded="false"
                    ><i class="ti-user"> </i>Username</a
                  >
                  <ul class="dropdown-menu">
                    <li class="nav-item">
                      <a class="nav-link" href="courses.html">Profile</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="course-details.html"
                        >Logout</a
                      >
                    </li>
                  </ul>
                </li> -->





                <li class="nav-item">
                  <a href="#" class="nav-link search" id="search">
                    <i class="ti-search"></i>
                  </a>
                </li>
                
              </ul>

            </div>
          </div>
        </nav>
      </div>

    </header>
    <!--================ End Header Menu Area =================-->

    <a class="btn btn-primary genric-btn info circle" data-toggle="modal" data-target="#demoModal" href="" id="demoClick" hidden=""></a>
    
    
    
    
    
    