<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Trainer extends CI_Controller {

	function __construct()
        {
            parent::__construct();
            
            $this->load->model("trainer_model");
        }
	public function index()
	{
		header("location:".base_url()."trainer/login");
	}
	
	public function login()
	{
	    $this->session->sess_destroy();
		$this->load->view('trainer/pages/login');
	}

    public function user_check()
    {   
        if($this->input->post('email_id')!="")
        {
        $email_id=$this->input->post('email_id');
        $mob_no=$this->input->post('mob_no');
        $data=$this->trainer_model->login($email_id,$mob_no);
        if($data["count"]>0)
        {
                    $full_name=$data['data']->full_name;
                    $the_session = array(
                        "user_type" => "trainer",
                        "trainer_id" => $data['data']->trainer_id,
                        "email_id" => $email_id,
                        "mob_no" => $mob_no,
                        "full_name" => $full_name
                        );
                    $this -> session -> set_userdata($the_session);
                    echo "<script>alert('You are already Registered. You can Update Your Profile Now.');window.location.href = '".base_url()."trainer/update_profile"."';</script>";
        }
                else
        {           
            date_default_timezone_set('Asia/Kolkata'); # add your city to set local time zone
	         		$now = date('Y-m-d H:i:s');
                    $data = array(
                         'email_id' => $this->input->post('email_id'),
                         'mob_no' => $this->input->post('mob_no'),
                         'signup_time' => $now);
                    $last_id=$this->trainer_model->insert_profile($data);
                    $the_session = array(
                        "user_type" => "trainer",
                        "trainer_id" => $last_id,
                        "email_id" => $email_id,
                        "mob_no" => $mob_no,
                        "full_name" => "Trainer"
                        );
                    $this -> session -> set_userdata($the_session);
                    echo "<script>alert('Sign Up Successful. Complete Your Registration Process.');window.location.href = '".base_url()."trainer/update_profile"."';</script>";
        }
        
        }
        
        else
        {
           header("location:".base_url()."trainer/index"); 
        }
        
            
    } 

        
        
    public function update_profile()
    {
        if($this ->session-> userdata('user_type')!="")
        {
        
        $data['course_types'] = $this->trainer_model->fetch_course_types();
        $data['districts'] = $this->trainer_model->fetch_districts();
		$data['regions'] = $this->trainer_model->fetch_regions();
		$data['branches'] = $this->trainer_model->fetch_branches();
		$data['subjects'] = $this->trainer_model->fetch_subjects();
        $trainer_id=$this ->session-> userdata('trainer_id');    
        $data['profile']=$this->trainer_model->fetch_profile($trainer_id);    
        $data['course']=$this->trainer_model->fetch_course($data['profile']['data']->course_stream); 
        $data['region_1']=$this->trainer_model->fetch_region($data['profile']['data']->prefered_region_1);    
        $data['region_2']=$this->trainer_model->fetch_region($data['profile']['data']->prefered_region_2);     
        $data['prefered_branch']=$this->trainer_model->fetch_prefered_branches($trainer_id);    
        $data['prefered_subjects']=$this->trainer_model->fetch_prefered_subjects($trainer_id);
        $this->load->view('trainer/templates/header', $data);
        $this->load->view('trainer/pages/update_profile', $data);
        $this->load->view('trainer/templates/footer', $data);
        }
        else
        {
		    header("location:".base_url()."trainer/index");
        }
    }  
        
        public function get_courses(){

      $res=$this->trainer_model->get_course_data($_GET["id"])->result();
      
      
        $data = "<option value='' selected='selected'>-- Select Course --</option>";
      foreach ($res as $key => $value) {
        $data .= "<option value='".$value->course_id."'>".$value->course_name."</option>";
      }
      echo json_encode($data);
   }
   
   public function get_course_streams(){

      $res=$this->trainer_model->get_stream_data($_GET["id"])->result();
      
        $data = "<option value='' selected='selected'>-- Select Stream / Specialization --</option>";
      foreach ($res as $key => $value) {
        $data .= "<option value='".$value->course_stream_id."'>".$value->course_stream_name."</option>"; 
      }  
      
      echo json_encode($data);
   }
   
    	public function get_regions(){

      $res=$this->trainer_model->get_region_data($_GET["id"])->result();
      
        $data = "<option value='' selected='selected'>-- Select Region --</option>";
      foreach ($res as $key => $value) {
        $data .= "<option value='".$value->region_id."'>".$value->region_name."</option>"; 
      }
      
       echo json_encode($data);
   }
   
   public function get_branches(){
        
      $trainer_id=$this ->session-> userdata('trainer_id');     
        $prefered_branches=$this->trainer_model->fetch_prefered_branches($trainer_id);
        $branches = array();
        foreach($prefered_branches as $prefered_branch) {
            $branches[] = $prefered_branch['branch_id'];
        }
      $res=$this->trainer_model->get_branch_data($_GET["id"],$_GET["id_2"])->result();
      
        // echo "<option>-- Select Branch --</option>";
    $data = "<table class='table table-bordered'>

                                <thead>
                                  <tr>
                                    <th style='text-align:center;'>Branch</th>
                                  </tr>
                                </thead>
                                <tbody>";
      foreach ($res as $key => $value) {
        // echo "<option value='".$value->studentgroupID."'>".$value->group."</option>"; 
        $data .= "<tr><td>";
        if(in_array($value->studentgroupID, $branches)){
            $data .= "<input type='checkbox' name='branch[]' id='branch_$value->studentgroupID' value='$value->studentgroupID' checked='checked'> $value->group";
        }
        else{
            $data .= "<input type='checkbox' name='branch[]' id='branch_$value->studentgroupID' value='$value->studentgroupID'> $value->group";
        }
        $data .= "</td></tr>";
      }   
      
      echo json_encode($data);
   }
    
    
    public function profile_data()
    {
        date_default_timezone_set('Asia/Kolkata'); # add your city to set local time zone
	         		$now = date('Y-m-d H:i:s');
        $trainer_id=$this ->session-> userdata('trainer_id');
        $this->trainer_model->delete_prefered_branches($trainer_id);
        $this->trainer_model->delete_prefered_subjects($trainer_id);
        $data = array(
                'full_name' => strtoupper($this->input->post('full_name')),
                'gender' => $this->input->post('gender'),
                'dob' => $this->input->post('dob'),
                'marital_status' => $this->input->post('marital_status'),
                'n_parent' => strtoupper($this->input->post('n_parent')),
                'parent_mob' => $this->input->post('parent_mob'),
                'h_name' => strtoupper($this->input->post('h_name')),
                'street_area' => strtoupper($this->input->post('street_area')),
                'city_town' => strtoupper($this->input->post('city_town')),
                'post' => strtoupper($this->input->post('post')),
                'district' => strtoupper($this->input->post('district')),
                'state' => strtoupper($this->input->post('state')),
                'pincode' => $this->input->post('pincode'),
                'email_id' => strtolower($this->input->post('email_id')),
                'mob_no' => $this->input->post('mob_no'),
                'course_stream' => $this->input->post('stream'),
                'course_status' => $this->input->post('course_status'),
                'year_of_pass' => $this->input->post('year_of_pass'),
                'academic_remarks' => strtoupper($this->input->post('academic_remarks')),
                'prefered_district' => $this->input->post('prefered_district'),
                'prefered_region_1' => $this->input->post('prefered_region_1'),
                'prefered_region_2' => $this->input->post('prefered_region_2'),
                'tuition_type' => $this->input->post('tuition_type'),
                'prefered_syllabus' => $this->input->post('prefered_syllabus'),
                'suggestion' => $this->input->post('suggestion'),
                'completion' => 0,
                'last_update_on' => $now);
        $this->trainer_model->update_profile($data,$trainer_id);
        $branches=$this->input->post('branch');
        $lp=$this->input->post('lp');
        $up=$this->input->post('up');
        $hs=$this->input->post('hs');
        $hss=$this->input->post('hss');
        if($branches != null)
		{
				foreach ($branches as $value) {

					$data = array(
						'trainer_id' => $trainer_id ,
						'branch_id' => $value
				 );
					$this->trainer_model->insert_trainer_branch($data);
				}
		}
		
		if($lp != null)
		{
				foreach ($lp as $value) {

					$data = array(
						'trainer_id' => $trainer_id ,
						'category_id' => 1 ,
						'subject_id' => $value
				 ); 
					$this->trainer_model->insert_trainer_subject($data);
				}
		}
		
		
		
		if($up != null)
		{
				foreach ($up as $value) {

					$data = array(
						'trainer_id' => $trainer_id ,
						'category_id' => 2 ,
						'subject_id' => $value
				 );
					$this->trainer_model->insert_trainer_subject($data);
				}
		}
		
		if($hs != null)
		{
				foreach ($hs as $value) {

					$data = array(
						'trainer_id' => $trainer_id ,
						'category_id' => 3 ,
						'subject_id' => $value
				 );
					$this->trainer_model->insert_trainer_subject($data);
				}
		}
		
		if($hss != null)
		{
				foreach ($hss as $value) {

					$data = array(
						'trainer_id' => $trainer_id ,
						'category_id' => 4 ,
						'subject_id' => $value
				 );
					$this->trainer_model->insert_trainer_subject($data);
				}
		}
        echo "<script>alert('Profile Updated Successfully.');window.location.href = '".base_url()."trainer/update_profile"."';</script>";
        // echo "<script>alert('Thank You for registering with us. Our Representative will contact you soon.');window.location.href = '".base_url()."trainer/logout"."';</script>";
    }
    
    public function logout()
	{
	    $this->session->sess_destroy();
	    echo "<script>alert('Thank You for registering with us. Our Representative will contact you soon.');window.location.href = '".base_url()."home/index"."';</script>";
	}


}
