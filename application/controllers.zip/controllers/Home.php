<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	function __construct()
		{
			parent::__construct();
			
			$this->load->model("main_model");
			//load our second db and put in $db2
            $this->db2 = $this->load->database('automation', TRUE);
		}

	public function index()
	{
		

		$nav['active'] = 'home';
        $data['district'] = $this->db2->get('district')->result_array();
		$data['trainers'] = $this->main_model->fetch_trainers();
		$data['banner'] = $this->main_model->fetch_banner();
		$data['testimonials'] = $this->main_model->fetch_testi();
		$data['p_courses'] = $this->main_model->fetch_p_courses();
		
		$this->db->order_by("id", "desc");
		$this->db->limit(2);
		$data['events'] = $this->db->get('events')->result_array();

		$this->db->where('id', '1');
		$data['counter'] =  $this->db->get('counter')->row_array();
        $this->db->order_by("id", "desc");
		$data['notification'] = $this->db->get('notification')->result_array();

		$this->load->view('user/templates/header',$nav);
		$this->load->view('user/pages/index',$data);
		$this->load->view('user/templates/footer');
	}

	public function downloads(){
		$nav['active'] = 'downloads';


		$this->load->view('user/templates/header',$nav);
		$this->load->view('user/pages/downloads');
		$this->load->view('user/templates/footer');
	}

	public function downloads_cat($cat){
		$cat = rawurldecode($cat);
		echo json_encode($this->main_model->get_downloads_category($cat));
	}

	public function downloads_view($type,$cat){
		$cat = rawurldecode($cat);
		$type = rawurldecode($type);
		echo json_encode($this->main_model->get_downloads_view($type,$cat));
	}

    public function fetch_region(){
        // echo json_encode("aa");SELECT * FROM `region` WHERE district_id = 10
        $this->db2 = $this->load->database('automation', TRUE);
        $this->db2->where("district_id", $this->input->post('district'));
        $region = $this->db2->get('region')->result_array();
        echo "<option>Select Region</option>";
        foreach($region as $r){
            echo '<option value = "'.$r['region_id'].'">'.$r['region_name'].'</option>';
        }
        
    }
    
    public function fetch_branch_info(){
//         $array = array('type' => $type, 'category' => $cat);
// 		$this->db->where($array);
// 		$query = $this->db->get('downloads');

        $this->db2 = $this->load->database('automation', TRUE);
        $this->db2->order_by("group", "asc");
        $this->db2->where("region_id", $this->input->post('region'));
        $query = $this->db2->get('studentgroup');

		$output='<div class="container">
        
        <div class="row d-flex justify-content-center">
        <div class="table-responsive">
          <table class="table table-striped table-bordered">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Branch Name</th>
              <th scope="col">Phone</th>
              <th scope="col">Email</th>
            </tr>
          </thead>
          <tbody>';
          
        //   $output .='<td>1</td><td>test</td><td>123456</td><td>test@gmail.com</td>'; //temp
		$temp = 1;
		foreach ($query->result() as $row) {
				$output .= '<tr>
              <th scope="row">'.$temp.'</th>
              <td>'.$row->group.'</td>
              <td><a href="tel:+917025841234" style="color:black;">'.'7025841234'.'</a></td>
              <td><a href="mailto:hello.teaminterval@gmail.com" style="color:black;">'.'hello.teaminterval@gmail.com'.'</a></td>
            </tr>';
            $temp = $temp + 1;
		}
			$output .= '</tbody>
        </table>

        </div>
        </div>
      </div>';
      echo $output;

// 		return $output;
    }
	public function contact(){
	    $this->db2 = $this->load->database('automation', TRUE);
		$nav['active'] = 'contact';
		$data['district'] = $this->db2->get('district')->result_array();


		$this->load->view('user/templates/header',$nav);
		$this->load->view('user/pages/contact',$data);
		$this->load->view('user/templates/footer');
	}

	public function about(){
		$nav['active'] = 'about';
		$data['faqs'] = $this->db->get('faq')->result_array();

		$this->load->view('user/templates/header',$nav);
		$this->load->view('user/pages/about',$data);
		$this->load->view('user/templates/footer');
	}

	public function events(){
		$nav['active'] = '';
		
		$this->db->order_by("id", "desc");
		$data['events'] = $this->db->get('events')->result_array();
		
		$this->load->view('user/templates/header',$nav);
		$this->load->view('user/pages/events',$data);
		$this->load->view('user/templates/footer');
	}


	function add_message(){
		// echo $this->main_model->adduniversity($this->input->post('university'));
			// echo $this->input->post('university');

		$data = array('name'=>$this->input->post('name'),'email'=>$this->input->post('email'),'subject'=>$this->input->post('subject'),'message'=>$this->input->post('message'));
	 	if($this->db->insert('messages',$data)){
	 		echo "Message sent";
	 	}
	 	else{
	 		echo "error";
	 	}
	}


	function book_demo(){
		date_default_timezone_set('Asia/Kolkata'); # add your city to set local time zone
	         		$now = date('Y-m-d H:i:s');
		$data = array('name'=>$this->input->post('name'),'email_id'=>$this->input->post('email'),'phone'=>$this->input->post('phone'),'to_meet_usertypeID'=>$this->input->post('branch_id'),'check_in'=>$now,'status'=>0,'reason'=>"Website",'note'=>"Demo Class for Std. - ".$this->input->post('class'),'representing'=>"Student/Parent",'schoolyearID'=>1);
	 	if($this->db2->insert('visitorinfo',$data)){
	 		echo "Demo Class booked. Our representative will contact you shortly..";
	 		
	 	}
	 	else{
	 		echo "error";
	 	}
	}
	
	public function signup(){
		$data['districts'] = $this->main_model->fetch_districts();
		$data['regions'] = $this->main_model->fetch_regions();
		$data['branches'] = $this->main_model->fetch_branches();
		$data['subjects'] = $this->main_model->fetch_subjects();
		$this->load->view('user/pages/signup', $data);
	}
	
	public function get_regions(){

      $res=$this->main_model->get_region_data($_GET["id"])->result();
      
        echo "<option>-- Select Region --</option>";
      foreach ($res as $key => $value) {
        echo "<option value='".$value->region_id."'>".$value->region_name."</option>"; 
      }   
   }
   
   public function get_branches(){

      $res=$this->main_model->get_branch_data($_GET["id"],$_GET["id_2"])->result();
      
        // echo "<option>-- Select Branch --</option>";
    echo "<table class='table table-bordered'>

                                <thead>
                                  <tr>
                                    <th style='text-align:center;'>Branch</th>
                                  </tr>
                                </thead>
                                <tbody>";
      foreach ($res as $key => $value) {
        // echo "<option value='".$value->studentgroupID."'>".$value->group."</option>"; 
        echo "<tr><td>";
        echo "<input type='checkbox' name='branch' id='branch'> $value->group";
        echo"</td></tr>";
      }   
   }
	
	public function joinus(){
		redirect("https://docs.google.com/forms/d/e/1FAIpQLSf1PM0MEdWSwJPQv0gInPH_wLArxoio8ErMNz5t1fae8xdPXQ/viewform");
	}
	
	public function employee(){
		redirect("https://docs.google.com/forms/d/e/1FAIpQLScwovtWKCLF4Z4EFWth585bgd8AFUj7S6jBrEDNZJjyuNu1EQ/viewform");
	}
	
	public function franchise(){
		redirect("https://docs.google.com/forms/d/e/1FAIpQLSeKWb2xSL3r8q2mZP-LXFujSZPGEYOyJ3Xfi2sPZUwuqP796A/viewform");
	}
	
	public function suggest(){
		redirect("https://docs.google.com/forms/d/e/1FAIpQLSdIrRvinUJTZ_HsLQE0bH5lI5AGcFq9Lham-UjreagPkxoq-w/viewform");
	}
	
	public function keam_neet_trainers(){
		redirect("https://docs.google.com/forms/d/e/1FAIpQLSdyLdrafeIiX5An5jadNoeDi8atDo9I5bIt3iCDZ3h5G4Xjbg/viewform");
	}
	
	public function jee_trainers(){
		redirect("https://docs.google.com/forms/d/e/1FAIpQLSc9zsh0DBOQiTgnZNGANbdRhBvhoIaDS3oXWnlc5Oj3im0s-g/viewform");
	}
	
	
	public function trainers($id){
	    
	    $this->db->where('id', $id);
	    $data['trainer']=$this->db->get('trainers')->row_array();
		$nav['active'] = 'home';


		$this->load->view('user/templates/header',$nav);
		$this->load->view('user/pages/single_trainer',$data);
		$this->load->view('user/templates/footer');
	}
	
	public function fetch_branches(){
        
        $this->db2->join('region', 'region.region_id = studentgroup.region_id');
        $this->db2->join('district', 'district.district_id = region.district_id');
        $this->db2->order_by("group", "asc");
        $this->db2->where("district.district_id", $this->input->post('district'));
        $query=$this->db2->get('studentgroup');
        $branch = $query->result_array();
        echo "<option value=''>Select Branch</option>";
        foreach($branch as $r){
            echo '<option value = "'.$r['studentgroupID'].'">'.$r['group'].'</option>';
        }
	}
	
	public function cron_job()
    {
        $this->db2->insert('test',array('temp'=>"bb"));
        echo "aa";
    }
    
    public function under_construction(){
		$this->load->view('user/pages/under_construction');
	}

}
